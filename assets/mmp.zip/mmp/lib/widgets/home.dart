import 'dart:io';
import 'package:searchfield/searchfield.dart';
import 'package:flutter/material.dart';
import 'package:mmp/widgets/assets.dart';
import 'package:mmp/widgets/circularButton.dart';
import 'package:mmp/widgets/postCard.dart';
import 'package:mmp/widgets/sections/headerButtonSection.dart';
import 'package:mmp/widgets/sections/room.dart';
import 'package:mmp/widgets/sections/statusSection.dart';
import 'package:mmp/widgets/sections/storySelection.dart';
import 'package:mmp/widgets/sections/suggestionSection.dart';
import 'package:mmp/widgets/theme.dart';
import 'package:mmp/widgets/widgets/headerButton.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:sizer/sizer.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:select_form_field/select_form_field.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'dart:convert';
import '../Screen/notification.dart';
import '../Screen/profile.dart';
import '../Screen/settings.dart';
import '../Screen/CountrySearch.dart';
import '../Screen/chatroom.dart';
import '../Screen/contacts.dart';
import '../Screen/profile.dart';
import '../Screen/searchfield.dart';
import '../Screen/settings.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: Padding(
          padding: EdgeInsets.all(0.0.h),
          child:  Home(),
        ),
      ),
    );
  }
}
class Home extends StatefulWidget {

  HomeState createState() => HomeState();
}
class HomeState extends State<Home> {

final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var dateNow = new DateTime.now();
  Icon customIcon = const Icon(Icons.search);
  Icon customMessages = const Icon(Icons.message);
  Widget customSearchBar = const Text('search');
  List<Map<String, dynamic>> todos = [];
  int _selectedIndex = 0;

List<page> display_list = List.from(main_search);
  static List<page> main_search = [];
static const _pages = <Widget>[
  FbCloneProfileStful(),//this is a stateful widget on a separate file
  settings(),//this is a stateful widget on a separate file
  notification(),
  //this is a stateful widget on a separate file
];

void _onItemTapped(int index) {
  setState(() {
    _selectedIndex = index;
  });
}
  final DescriptionController = TextEditingController();
  Color butt = Colors.pink;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
    backgroundColor: Colors.lightBlue,
   // elevation: 0,
    title: Text(
    "faceMe",
    style: TextStyle(
    color: Colors.white,
    fontSize: 26,
    fontWeight: FontWeight.bold,
    ),),
            automaticallyImplyLeading: false,
            actions: [
              IconButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => CountrySearch(
                        title: 'Country List',
                      )));
                },
                icon: customIcon,
                color: Colors.white,
              ),
              IconButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) =>  chatroom()));
                },
                icon: customMessages,
             color: Colors.white, )
            ],
            centerTitle: true,
          ),
          body: ListView(
            children: [
              SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StatusSection(),
                    Divider(
                      thickness: 1,
                      color: Colors.grey[300],
                    ),
                    HeaderButtonSection(
                        buttonOne: headerbutton(
                            buttontext: "Live",
                            buttonicon: Icons.video_call,
                            buttonaction: () {

                            },
                            buttoncolor: Colors.red),
                        buttonTwo: headerbutton(
                            buttontext: "Photos",
                            buttonicon: Icons.photo_library,
                            buttonaction: () {

                            },
                            buttoncolor: Colors.green),
                        buttonThree: headerbutton(
                            buttontext: "Room",
                            buttonicon: Icons.video_call,
                            buttonaction: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => record()));
                            },
                            buttoncolor: Colors.purple)),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    Room(),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    StorySection(),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    PostCard(
                      varifiedpost: true,
                      pics: ylw,
                      name: "Spiderman",
                      time: "4h",
                      postImage: bat,
                      postTitle: "hay gorgeous",
                      like: "15K",
                      comments: "2K",
                      share: "432",
                    ),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    PostCard(
                      varifiedpost: true,
                      pics: bat,
                      name: "Batman",
                      time: "8h",
                      postImage: sup,
                      postTitle: "yoo bud",
                      like: "30K",
                      comments: "2K",
                      share: "344",
                    ),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    PostCard(
                      varifiedpost: true,
                      pics: red,
                      name: "Scarlett",
                      time: "4h",
                      postImage: bat,
                      postTitle: " I am scarlett,",
                      like: "15K",
                      comments: "2K",
                      share: "232",
                    ),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    SuggestionSection(),
                    Divider(
                      thickness: 10,
                      color: Colors.grey[300],
                    ),
                    PostCard(
                      varifiedpost: true,
                      pics: haf,
                      name: "Batman",
                      time: "8h",
                      postImage: sup,
                      postTitle:
                      "yooo dude how are you man..",
                      like: "15K",
                      comments: "2K",
                      share: "211",
                    ),
                  ],
          ),
              ),
      ],),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            items: [
              BottomNavigationBarItem(
                  icon: Icon(Icons.home, color: Colors.grey[700]),
                  label: "",
                  backgroundColor: Colors.blueAccent),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person, color: Colors.grey[700]),
                  label: "",
                  backgroundColor: Colors.white),
              BottomNavigationBarItem(
                  icon: Icon(Icons.settings, color: Colors.grey[700]),
                  label: "",
                  backgroundColor: Colors.blueAccent),
              BottomNavigationBarItem(
                  icon: Icon(Icons.notifications, color: Colors.grey[700]),
                  label: "",
                  backgroundColor: Colors.white),
              BottomNavigationBarItem(
                  icon: Icon(Icons.more_vert_outlined, color: Colors.grey[700]),
                  label: "",
                  backgroundColor: Colors.blueAccent),
            ],
            onTap: _onItemTapped,

            type: BottomNavigationBarType.shifting,

          ),
         );
  }
}

class record extends StatefulWidget {
  const record({Key? key}) : super(key: key);

  @override
  State<record> createState() => _recordState();
}

class _recordState extends State<record> {
  @override
  Widget build(BuildContext context) {
    return ListWheelScrollView(itemExtent: 2, children: [
      Container(
        child: Image (image: AssetImage("assetsm1.jpg/"),
        ),
      ),
      Divider(
        thickness: 10,
        color: Colors.black,
      ),
      Container(
    child: Image (image: AssetImage("assetsw1.jpg/"),
       ),
      ),
      Divider(
        thickness: 10,
        color: Colors.black,
      ),
    ]);
  }
}
