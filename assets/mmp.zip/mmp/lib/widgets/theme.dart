import 'package:flutter/material.dart';

class CustomTheme {
  static final lightTheme = ThemeData.light();
  static final darkTheme = ThemeData.dark();
}
