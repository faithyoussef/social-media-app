String sup = "assets/dc_comics_superman_hd_fortnite-1920x1080.jpg";
String bat = "assets/dc_comics_superhero_hd_batman-1600x900.jpg";
String haf = "assets/m1.jpg";
String red = "assets/w2.jpg";
String ylw = "assets/w1.jpg";
String plp = "assets/m2.jpg";



List<String>  location = ["istanbul","baghdad","malta", "dubai", "amman", "beurit" , "cairo" , "damascus", "muscat"];
List<String>  feelings = ["moody :/ ","beaming *-*", "lonely :0 ", "happy :)", " pissed :# ", "surprised o.O", "anxious :8"];
List<String>  weather = ["cloudy", "sunny", "sky is clear", "rainy", "dusty"];
List<String>  Interests = ["football", "vollyball", "basketball", "art", "science"];
List<String>  gender = ["female", "male"];

