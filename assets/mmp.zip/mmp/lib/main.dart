import 'package:flutter/material.dart';
import 'package:mmp/widgets/home.dart';
import 'package:webview_flutter/webview_flutter.dart';
void main() => runApp(MaterialApp(
  title: "FaceMe",
  home: Home(),
));


