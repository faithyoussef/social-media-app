
import 'dart:core';

import 'package:flutter/material.dart';

import 'CountrySearch.dart';

class page{
  String? title;
  String? name;
  String? post;
  int? date;
  double? mutual;

  page(this.title,
      this.name,
      this.post,
      this.date,
      this.mutual);}
